Website template: https://github.com/trustedmercury/discord-bot-website-template 
